﻿Shelf Windows 11 v0.1 軽量版（x64）

この版には.NETランタイムを同梱していません。
1. Microsoft公式ページを開いてください。
   https://dotnet.microsoft.com/download/dotnet/8.0
2. 「.NET Desktop Runtime 8.0」の Windows x64 版をインストールしてください。
   ASP.NET Core Runtimeや通常の.NET RuntimeだけではWPFを起動できません。
   .NET 8 SDKがすでにある場合は通常追加導入不要です。
3. ZIPを右クリックし「すべて展開」を選びます。
4. 展開したフォルダーのShelf.Windows.exeをダブルクリックします。
   他のDLL・JSONファイルを移動・削除しないでください。
   管理者として実行しないでください。

テスト用ファイルを棚へドロップし、その行を別フォルダーへドラッグしてください。
コピー操作のみで、棚の項目は残ります。終了すると一覧は失われます。
Windows 11実機での起動・ドラッグ操作は未検証です。
未署名の試作版です。警告が出た場合は入手元を確認し、保護機能は無効化しないでください。
